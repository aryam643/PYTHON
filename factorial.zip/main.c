/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>

int main()
{
    int a, num;
    long Factorial = 1;
    printf("Enter the number to find factorial: ");
    scanf("%d", &num);
    for(a = 1; a <= num; a++)
    {
        Factorial = Factorial * a;
    }
    printf("\n Factorial of %d = %ld", num, Factorial);
    return 0;
}


