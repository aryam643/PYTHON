/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>



int main()
{
    char ch;
    int ascii;
    printf("Enter a character: ");
    scanf("%c", &ch);
    ascii = ch;

    printf("ASCII value of %c is: %d\n",ch,ascii);


    //for capital characters (A to Z)
    if (ascii >= 65 && ascii <= 90)
        {
            printf("%c is a capital letter", ch);
        }

    //for small characters (a to z)
    else if (ascii >= 97 && ascii <=122)
       {
            printf("%c is a small letter", ch);
       }
    //for digits (0 to 9)
    else if (ascii >=48 && ascii <= 57)
        {
            printf("%c is a digit", ch);
        }

    //for special symbols
    else if (ascii>=0 && ascii<=47 || ascii>=58 && ascii<=64 || ascii>=91 && ascii<=96 || ascii>=123 && ascii<=127)
        {
            printf("%c is a special symbols", ch);
        }

    return 0;
}
