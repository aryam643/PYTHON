/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char name[25];
    int a,b,c ;
    float k;
    printf("Enter Name: ");
    scanf("%[^\n]",name);
    printf("Enter Roll No.: ");
    scanf("%d",&a);
    printf("Enter Maximum Marks = ");
    scanf("%i",&b);
    printf("Enter Marks Obtained = ");
    scanf("%i",&c);
    printf("Enter your +2 Percentage = ");
    scanf("%f",&k);
    
    printf("\n Name : %s\n",name);
    printf("Roll No. : %d\n",a);
    printf("Maximum Marks : %i\n",b);
    printf("Marks Obatined : %i\n",c);
    printf("+2 Percentage : %f\n",k);
    
    
    return 0;
}


