/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h> 
int main()
{
   int i,n;
   float sum=0.0;
   printf("Input the number of terms : ");
   scanf("%d",&n);
   printf("\n\n");
   for(i=1;i<=n;i++)
   {
       if(i<n)
       {
     printf("1/%d + ",i);
     sum= sum + 1/(float)i;
       }
     if(i==n)
     {
     printf("1/%d ",i);
     sum= sum + 1/(float)i;
     }
     }
        printf("\nSum of Series upto %d terms : %f \n",n,sum);
}  
