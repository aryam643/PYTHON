#include <math.h>
#include <stdio.h>

int checkPrimeNumber(int n);
int checkArmstrongNumber(int n);

int main() {
   int n, result;
   printf("Enter a positive integer: ");
   scanf("%d", &n);

   
   result = checkPrimeNumber(n);
   if (result == 1)
      printf("%d is a prime number.\n", n);
   else
      printf("%d is not a prime number.\n", n);
      
      return 0;
}


int checkPrimeNumber(int n) {
   int i, result = 1, squareRoot;

   
   squareRoot = sqrt(n);
   for (i = 2; i <= squareRoot; ++i) {
     
      if (n % i == 0) {
         result = 0;
         break;
      }
   }
   return result;
}


