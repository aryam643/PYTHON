/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   float cost_price, selling_price, profit, loss;

    printf("Enter the cost price of an item: ");
    scanf("%f", &cost_price);

    printf("Enter the selling price of an item: ");
    scanf("%f", &selling_price);

    if (selling_price > cost_price)   //here we get profit on selling item
    {
        profit = selling_price - cost_price;
        printf("We earn %.2f profit by selling item.", profit);

    }

    else if (selling_price < cost_price)   //here we get loss on selling item
    {
        loss = cost_price - selling_price;
        printf("\nWe incurred %.2f loss on selling item.", loss);
    }

    else    //here we don't get any loss and profit on selling item when (cost price == selling price)
    {
        printf("\nWe don't get any loss and profit on selling item");
    }

    return 0;
}
