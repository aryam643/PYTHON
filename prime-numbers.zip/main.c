/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
    int num,i,a,b,c;

    printf("Input starting number of range: ");
    scanf("%d",&b);

    printf("Input ending number of range : ");
    scanf("%d",&c);
    printf("The prime numbers between %d and %d are : \n",b,c);
  
    for(num = b;num<=c;num++)
       {
         a = 0;

         for(i=2;i<=num/2;i++)
            {
             if(num%i==0){
                 a++;
                 break;
             }
        }
        
         if(a==0 && num!= 1)
             printf("%d ",num);
    }
     printf("\n");
     return 0;
}

