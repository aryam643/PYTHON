#include <iostream>
using namespace std;
 
int numberoftrailingzeros(int n)
{
   
    int count = 0;
   while(n/5>0)
   {
       count+=(n/5);
       n/=5;
       
   }
    return count;
}
 
int main()
{
    int T;
    cin>>T;
    while(T-->0)
    {
      int n;
      cin>>n;
      cout<<numberoftrailingzeros(n)<<endl;
    
    }
 
    return 0;
}