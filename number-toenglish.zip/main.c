/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n;
    printf("");
    scanf("%d",&n);
    if(n>=1&&n<=9)
    {
        if(n==1)
        {
            printf("one");
        }
        else if(n==2)
        {
            printf("two");
        }
        else if(n==3)
        {
            printf("three");
        }
        else if(n==4)
        {
            printf("four");
        }
        else if(n==5)
        {
            printf("five");
        }
        else if(n==6)
        {
            printf("six");
        }
        else if(n==7)
        {
            printf("seven");
        }
        else if(n==8)
        {
            printf("eight");
        }
        else if(n==9)
        {
            printf("nine");
        }
    }
    else
    {
        printf("Greater than 9");
    }
    return 0;
}
