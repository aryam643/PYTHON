/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    int a, b, num;
    printf("Enter the number: ");
    scanf("%d", &a);
    printf("Enter the number in power: ");
    scanf("%d", &b);
    
    num = pow(a,b);
    
    printf("%d raise to the power %d = %d", a, b, num);
    

    return 0;
}
