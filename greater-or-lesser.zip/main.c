/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int x;
    printf("Enter an integer:");
    scanf("%d", &x);
    if (x>=1000)
    {
    printf("hugely positive");
    }
    else if (x>=100 && x<999)
    {
        printf("very positive");
    }
    else if(x>0 && x<100)
    {
        printf("positive");
    }
    else if(x==0)
    {
        printf("zero");
    }
    else if(x<0 && x>-100)
    {
        printf("negative");
    }
    else if( x<=-100 && x>-999)
    {
        printf("very negative");
    }
    else if(x<=-1000)
    {
        printf("hugely negative");
    }
    return 0;
}
