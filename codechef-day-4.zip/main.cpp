#include<iostream>
#include<climits>
using namespace std;

int maxSum(int a[], int size)
{
    int max_so_far = INT_MIN, max_ending_here = 0;

    for (int i = 0; i < size; i++)
    {
        max_ending_here = max_ending_here + a[i];
        if (max_so_far < max_ending_here)
            max_so_far = max_ending_here;

        if (max_ending_here < 0)
            max_ending_here = 0;
    }
    return max_so_far;
}

int main()
{
    int a[] = {-3,-4,5,-1,2,-4,6,-1};
    int n = sizeof(a)/sizeof(a[0]);
    int max_sum = maxSum(a, n);
    cout << "Maximum Sum= " << max_sum;
    return 0;
}

//https://www.geeksforgeeks.org/largest-sum-contiguous-subarray/