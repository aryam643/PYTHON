/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float radius, area;
    
    printf("Radius of circle = ");
    scanf("%f", &radius);
    
    area = 3.14159265*radius*radius;
    printf("\nArea of circle = %f unit sq. \n",area);

    return 0;
}
