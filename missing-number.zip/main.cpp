#include <bits/stdc++.h>
using namespace std;


int missing_number(int a[], int x)
{

    int total = (x + 1) * (x + 2) / 2;
    for (int i = 0; i < x; i++)
        total -= a[i];
    return total;
}


int main()
{
    int arr[] = {2,3,1,5};
    int x = sizeof(arr) / sizeof(arr[0]);
    int miss = missing_number(arr, x);
    cout << miss;
}