/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<conio.h>
#include<math.h>
int main()
{
    int a, b, c, x;

    printf("Enter the number: ");
    scanf("%d", &a);
    printf("Enter the number in power: ");
    scanf("%d", &b);
   
    c = 1;
    x = b;
    while(b!=0)
    {
        c = c * a;
        b = b - 1;
    }
    printf("%d raised to the power %d: %d",a,x,c);
}
