/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i =17;
    int j =2;
    int k =3;
    
    printf("\n i is less than j: %d", i<j);
    printf("\n j is less than equal to i: %d", j<i);
    printf("\n i is less than eqaul to  j: %d", i<=j);
    printf("\n j is less than equal to i: %d", j<=i);
    printf("\n");
    

    return 0;
}
