/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j;
    long ix;
    short s;
    unsigned u;
    float x;
    double dx;
    char c;
    scanf("%d %d %f %lf \n",&i,&j,&x,&dx);
    scanf("%d %ld %d %f %u \n",&i,&ix,&j,&x,&u);
    scanf("%d %u %c \n",&i,&u,&c);
    scanf("%c %f %lf %hi \n",&c,&x,&dx,&s);
    
    printf("%d %d %f %lf \n",i,j,x,dx);
    printf("%d %ld %d %f %u \n",i,ix,j,x,u);
    printf("%d %u %c \n",i,u,c);
    printf("%c %f %lf %hi \n",c,x,dx,s);
    return 0;
    
    
}
