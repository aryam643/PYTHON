/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>  
  
int main()  
{  
    int y, z;  
    float i, x;  
    printf("");
    scanf("%d", &z);
    if(z>=0&&z<=11)
    {
        for(y = 1; y <= z; y++)  
      {  
        for(x = 5.5; x <= 7.5; x += 0.5)  
        {  
          i = 2 + (y + 0.5 * x);  
  
          printf("y = %d, x = %0.2f and  i = %0.2f\n",y,x,i);  
        }  
      }  
    }
    else
    {
        printf("Outside the range");
    }
  
    return 0;  
}  