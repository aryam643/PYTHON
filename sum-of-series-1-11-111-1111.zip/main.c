/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int i,n;
   long sum=0;
   long int t=1;
   printf("Input the number of terms : ");
   scanf("%d",&n);
   for(i=1;i<=n;i++)
   {
       printf("%ld ",t);
       if (i<n){
           printf("+ ");
           
       }
   sum=sum+t;
   t=(t*10)+1;
   }
   printf("\nThe Sum is : %ld\n",sum);

    return 0;
}
