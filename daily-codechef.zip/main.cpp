#include<iostream>
using namespace std;
int CountOddDigits(int x[], int n)
{
    int count=0;
    int result=0;
    for(int i = 0; i<n; i++)
    {
          count = 0;
          while(x[i] != 0)
        {
            x[i] /= 10;
            count ++;
               
        }
        if(count % 2 != 0)  result += 1;
    }
    return result;
}

int main()
{
    int n;
    cout<<"Enter no. of integers : ";
    cin>>n;
    int x[n];
    for(int i=0; i<n; i++) cin>>x[i];
    cout<<"Number of elements = "<<CountOddDigits(x,n);
    
    return 0;
}