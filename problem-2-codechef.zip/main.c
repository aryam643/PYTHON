#include <stdio.h>

int move_zeros(int A[], int n)
{
    int k = {0};  

    for (int i = 0; i < n; i++)
        if (A[i] != 0)
            A[k++] = A[i]; 

    while (k < n)
        A[k++] = 0;
}


int main()
{
    int A[5];
    printf("Enter the elements: \n");
     for(int i = 0; i < 5; ++i) 
    {
     scanf("%d", &A[i]);
    }
    int n = sizeof(A) / sizeof(A[0]);
    move_zeros(A, n);
    printf("%s\n", "Array after moving all zeros:");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", A[i]);
    }

    return 0;
}
