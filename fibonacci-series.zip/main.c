#include<stdio.h>

void fibonacci_series (int);

void main()
{
   int n;

   printf("Enter a number: ");
   scanf("%d", &n);

   printf("\nThe Fibonacci series is: \n");

   fibonacci_series(n);

}

void fibonacci_series(int n)
{
   int i,c=0;
   int a=0;
   int b=1;
   for(i=0;i<n;i++)
   {
       printf("%d ",c);
       a=b;
       b=c;
       c=a+b;
   }
}