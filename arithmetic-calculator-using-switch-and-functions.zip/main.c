#include <stdio.h>

float add(float x, float y);
float sub(float x, float y);
float mult(float x, float y);
float division(float x, float y);

float add(float x, float y)
{
    return x + y;
}


float sub(float x, float y)
{
    return x - y;
}


float mult(float x, float y)
{
    return x * y;
}

float division(float x, float y)
{
    return x / y;
}



int main()
{
    char operation;
    float x, y, result=0.0f;
    
    printf("ARITHMETIC CALCULATOR \n\n");
    printf("Enter [x] [operation: + - * /] [y] \n");
    scanf("%f %c %f", &x, &operation, &y);

    switch(operation)
    {
        case '+': 
            result = add(x, y);
            break;

        case '-': 
            result = sub(x, y);
            break;

        case '*': 
            result = mult(x, y);
            break;

        case '/': 
            result = division(x, y);
            break;

        default: 
            printf("Invalid operator used\n ");
    }

    printf("%.2f %c %.2f = %.2f", x, operation, y, result);

    return 0;
}





