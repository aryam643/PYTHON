/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void div_rem(int a, int b, int *divides, int *remains);
int main()
{
    int a, b;
    int div = 0;
    int rem = 0;
    scanf("%i%i", &a, &b);
    if ( 0<a && a<100 && 0<b && b<100)
    {
    div=a/b;
    printf("%i divided by %i = %i and remainder is %i\n", a, b, div, rem);
    }
    else
    {
    printf("Outside the range");
  }
    return 0;
}
void div_rem(int a, int b, int *divides, int *remains)
{
    *divides = a / b;
    *remains = a % b;
}