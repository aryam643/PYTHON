/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int main()
{
   int x1,x2,x3,y1,y2,y3,area;
    printf("");//enter x1,y1
    scanf("%d,%d",&x1,&y1);
    printf("");//enter x2,y2
    scanf("%d,%d",&x2,&y2);
    printf("");//enter x3,y3
    scanf("%d,%d",&x3,&y3);
    
    area= (x1*(y2-y3) + x2*(y3-y1) + x3*(y1-y2));
    
    if(area==0)
    {
        printf("All 3 points lie on the same line");
    }
    else 
    {
        printf("All 3 points do not lie on the same line");
    }

    
}