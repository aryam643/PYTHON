/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int x, y, w_x=0;

    printf("Enter a number: ");
    scanf("%d", &x);
    y = x;
    while(x!=0)
    {
        w_x = w_x * 10;

        w_x = x % 10 + w_x;

        x = x/10;
    }
    printf("Reversed number of %d is %d\n",y, w_x);

    if (y==w_x)
        {
            printf("Input number %d & Reversed number %d are equal", y, w_x);
        }
    else
        {
            printf("Input number %d & Reversed number %d are not equal", y, w_x);
        }

    return 0;
}
